Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 ../Core/Inc/stm32f4xx_hal_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f429xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma2d.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sdram.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_fmc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_ltdc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_ltdc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h \
 ../Core/Src/stm32f429i_discovery.h \
 ../Core/Src/stm32f429i_discovery_lcd.h \
 ../Core/Src/stm32f429i_discovery_sdram.h ../Core/Src/fonts.h \
 ../Core/Src/ili9341.h ../Core/Src/lcd.h
../Core/Inc/main.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
../Core/Inc/stm32f4xx_hal_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f429xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma2d.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_sdram.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_fmc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_ltdc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_ltdc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_spi.h:
../Core/Src/stm32f429i_discovery.h:
../Core/Src/stm32f429i_discovery_lcd.h:
../Core/Src/stm32f429i_discovery_sdram.h:
../Core/Src/fonts.h:
../Core/Src/ili9341.h:
../Core/Src/lcd.h:
